package com.kazumodz.subakti;




import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.RadioGroup;
import android.widget.Spinner;



public class galauyt extends Activity
{

	private String gameName;

	
	
	private int gameType;

	private View mainView;
    private RadioGroup radiogroup2;
	private RadioGroup radioMod;
	private RadioGroup radioBit;
	
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.galau);

		






    } 
    private void ExecuteElf(String shell)
    {
        String s=shell;

        try
        {
            Runtime.getRuntime().exec(s,null,null);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
	
	

				
				
		
	}

	


	



