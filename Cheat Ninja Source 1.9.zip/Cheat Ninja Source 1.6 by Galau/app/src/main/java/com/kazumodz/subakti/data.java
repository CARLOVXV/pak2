package com.kazumodz.subakti;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Toast;

public class data extends Activity
{

	static boolean is32 = false;
	static boolean is64 = false;
	static boolean bitMod = false;
	private ProgressDialog ProgressDialog;
	public static native void LoadContent(String dir);
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.data);

		
		final ProgressDialog progressDoalog = new ProgressDialog(this); 
		final Handler handle = new Handler() { 
			@Override 
			public void handleMessage(Message msg) {
				super.handleMessage(msg); 
				progressDoalog.incrementProgressBy(1); 
			} 
		}; 
		progressDoalog.setMax(100); 
		progressDoalog.setMessage(""); 
		progressDoalog.setTitle("Downloading data...."); 
		progressDoalog.setCancelable(false);
		progressDoalog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL); 
		progressDoalog.show(); 
		new Thread(new Runnable() { 
				@Override public void run() { 
					try { 
						while (progressDoalog.getProgress() <= progressDoalog.getMax()) { 
							Thread.sleep(15); 
							handle.sendMessage(handle.obtainMessage()); 
							if (progressDoalog.getProgress() == progressDoalog.getMax()) { 
								progressDoalog.dismiss(); 
							} 
						} 
					} catch (Exception e) {
						e.printStackTrace(); 
					} 
				} 
			}).start();
		
		findViewById(R.id.data1).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/galauyt")));
                }
			}
		);
		
		
		GradientDrawable galau = new GradientDrawable();
        galau.setCornerRadius(100); //Set corner
        galau.setColor(Color.parseColor("#00FFFFFF")); //Set background color
        galau.setStroke(2, Color.parseColor("#FFFFFF")); //Set border	
		findViewById(R.id.xnxx).setBackground(galau);
		
		
		GradientDrawable gradientdrawable = new GradientDrawable();
        gradientdrawable.setCornerRadius(40); //Set corner
        gradientdrawable.setColor(Color.parseColor("#FF2CB4C0")); //Set background color
        gradientdrawable.setStroke(2, Color.parseColor("#FF2CB4C0")); //Set border
        findViewById(R.id.data1).setBackground(gradientdrawable);
		GradientDrawable gradientdrawable4 = new GradientDrawable();
        gradientdrawable4.setCornerRadius(25); //Set corner
        gradientdrawable4.setColor(Color.parseColor("#FF525252")); //Set background color
        gradientdrawable4.setStroke(2, Color.parseColor("#FF525252")); //Set border
		findViewById(R.id.loader).setBackground(gradientdrawable4);
		GradientDrawable gradientdrawable2 = new GradientDrawable();
        gradientdrawable2.setCornerRadius(25); //Set corner
        gradientdrawable2.setColor(Color.parseColor("#FF525252")); //Set background color
        gradientdrawable2.setStroke(2, Color.parseColor("#FF525252")); //Set border
		findViewById(R.id.loader1).setBackground(gradientdrawable2);
		findViewById(R.id.loader).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					
					
						
					Toast.makeText(data.this,"PUBG MOBILE 1.6.0 SAVED",Toast.LENGTH_LONG).show();
					startActivity(new Intent(data.this, MainActivity.class));
					finish();
                }

			}

		);
		findViewById(R.id.loader1).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {

					AlertDialog.Builder builder = new AlertDialog.Builder(data.this);
					builder.setTitle("Coming Soon!!!")
						.setMessage("PUBG Mobile 1.7.0 is Coming Soon")
						.setCancelable(false)
						.setNegativeButton("OKE", new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {
								//clicked
							}
						});
					AlertDialog alert = builder.create();
					alert.show();
                }
			}
		);
	}
}

