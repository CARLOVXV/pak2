package com.kazumodz.subakti;

import android.annotation.SuppressLint;
import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.*;
import android.os.*;
import android.provider.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.support.v7.app.*;
//import androidx.appcompat.app.*;

import java.io.*;
import java.lang.*;


public class MainActivity extends AppCompatActivity implements OnClickListener {
    String gameName = "com.tencent.ig";
    static int gameType = 1;

	public static boolean isNoroot;

    static {
        System.loadLibrary("kazumodz-native");
    }
	
	private static boolean togglev1=false;
	private void StartFloatToggle1() {
        startService(new Intent(this, Toggle.class));
    }
    private void StopFloatToggle1() {
        stopService(new Intent(this, Toggle.class));
    }
	
	
	

	
    private boolean isDisplay = false, isMenuDis = false;
    Context ctx;
    public static String socket;
    public String daemonPath, daemonPath64;
    static boolean isRoot = false, isNoRoot = false, rootMod = false, is32 = false, is64 = false, bitMod = false, verMod = true, isDaemon = false;
    public LinearLayout button1, button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        CheckFloatViewPermission();
        ctx = this;
        button1 = (LinearLayout) findViewById(R.id.button1);
        button2 = (LinearLayout) findViewById(R.id.button2);
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
		
        RadioGroup deviceinfo = (RadioGroup) findViewById(R.id.radioMod);
        RadioGroup bitversion = (RadioGroup) findViewById(R.id.radioBit);/*
        final String[] version = {"Global", "Korea", "Vietnam", "Taiwan", "India(32bit)"};
      final Spinner spin = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, version);
     dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(dataAdapter);
      spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (spin.getSelectedItem().toString().equals("India(32bit)")) {
                    gameName = "com.pubg.imobile";
                    gameType = 5;
                } else if (spin.getSelectedItem().toString().equals("Taiwan")) {
                    gameName = "com.rekoo.pubgm";
                    gameType = 4;
                } else if (spin.getSelectedItem().toString().equals("Korea")) {
                    gameName = "com.pubg.krmobile";
                    gameType = 2;
                } else if (spin.getSelectedItem().toString().equals("Vietnam")) {
                    gameName = "com.vng.pubgmobile";
                    gameType = 3;
                } else {
                    gameName = "com.tencent.ig";
                    gameType = 1;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });*/
		
		
		RadioGroup radiogame = (RadioGroup) findViewById(R.id.radiogame);
		radiogame.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
				@SuppressLint("NonConstantResourceId")
				@Override
				public void onCheckedChanged(RadioGroup group, int checkedId) {
					switch (checkedId) {


						case R.id.global:
							gameName = "com.tencent.ig";
							gameType = 1;
							break;


						case R.id.korea:
							gameName = "com.pubg.krmobile";
							gameType = 2;
							break;

						case R.id.vieatnam:

							gameName = "com.vng.pubgmobile";
							gameType = 3;
							break;


						case R.id.taiwan:
							gameName = "com.rekoo.pubgm";
							gameType = 4;					
							break;

						case R.id.bgmi:
							gameName = "com.pubg.imobile";
							gameType = 5;	
							break;		



					}
				}
			});
		
		
		
        deviceinfo.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @SuppressLint("NonConstantResourceId")
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.radiobutton3:
                        isRoot = true;
                        ExecuteElf();
                        isNoRoot = false;
                        rootMod = true;
                        break;
                    case R.id.radiobutton4:
                        isNoRoot = true;
                        isRoot = false;
                        rootMod = true;
                        break;
                }
            }
        });
        bitversion.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @SuppressLint("NonConstantResourceId")
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.radiobutton5:
                        is32 = true;
                        is64 = false;
                        bitMod = true;
                        break;
                    case R.id.radiobutton6:
                        is64 = true;
                        is32 = false;
                        bitMod = true;
                        break;
                }
            }
        });
		
		findViewById(R.id.status).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					startActivity(new Intent(getApplicationContext(), status.class));
                }
			}
		);
		
		
		GradientDrawable galau = new GradientDrawable();
        galau.setCornerRadius(40); //Set corner
        galau.setColor(Color.parseColor("#A2FFFFFF")); //Set background color
        galau.setStroke(5, Color.parseColor("#A2FFFFFF")); //Set border
        findViewById(R.id.ppp).setBackground(galau);
		
		
		
        GradientDrawable gradientdrawable = new GradientDrawable();
        gradientdrawable.setCornerRadius(40); //Set corner
        gradientdrawable.setColor(Color.parseColor("#FF1500")); //Set background color
        gradientdrawable.setStroke(2, Color.parseColor("#FF1500")); //Set border
        findViewById(R.id.button2).setBackground(gradientdrawable);
        GradientDrawable gradientdrawable2 = new GradientDrawable();
        gradientdrawable2.setCornerRadius(40); //Set corner
        gradientdrawable2.setColor(Color.parseColor("#0091EA")); //Set background color
        gradientdrawable2.setStroke(2, Color.parseColor("#0091EA")); //Set border
        findViewById(R.id.button1).setBackground(gradientdrawable2);
		
        ExecuteElf("su -c");
        loadAssets();
        loadAssets64();
		loadXnxx();
        socket = daemonPath;
    }

	private void ExecuteElf(java.lang.String p0) {
	}

    @SuppressLint("NonConstantResourceId")
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button1:
                if (!isDisplay && !isMenuDis) {
                    if (!rootMod || !verMod || !bitMod) {
                        Toast.makeText(MainActivity.this, "Please Select Settings First !!", Toast.LENGTH_LONG).show();
                    } else {
                        if (isNoRoot) {
                            if (is32) {
                                socket = daemonPath;
                            } else if (is64) {
                                socket = daemonPath64;
                            }
                        }
                        if (isRoot) {
                            if (is32) {
                                socket = "su -c " + daemonPath;
                            } else if (is64) {
                                socket = "su -c " + daemonPath64;
                            }
                        }
						//Intent launch = getPackageManager().getLaunchIntentForPackage("com.tencent.ig"); 

						//if (launch != null) { startActivity(launch); }
                        startPatcher();
                        startService(new Intent(this, Overlay.class));
                        isDisplay = true;
                        isDaemon = true;
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Already Started !!", Toast.LENGTH_LONG).show();
                }
                break;
            case R.id.button2:
                if (isDisplay) {
					StopFloatToggle1();
					togglev1 = false;
                    isDisplay = false;
                    isMenuDis = false;
                    isDaemon = false;
                    stopService(new Intent(this, FloatLogo.class));
                    stopService(new Intent(this, Overlay.class));
                }
                break;
        }
    }

    public void CheckFloatViewPermission() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Enable Floating Permission ", Toast.LENGTH_LONG).show();
            startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())), 0);
        }
    }

    private boolean isServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (manager != null) {
            for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                if (FloatLogo.class.getName().equals(service.service.getClassName())) {
                    return true;
                }
            }
        }
        return false;
    }

    void startPatcher() {
        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, 123);
        } else {
            startFloater();
        }
    }

    private void startFloater() {
        if (!isServiceRunning()) {
            startService(new Intent(this, FloatLogo.class));
        } else {
            Toast.makeText(this, "Service Already Running!", Toast.LENGTH_SHORT).show();
        }
    }

    private void ExecuteElf() {
        try {
            Runtime.getRuntime().exec("su -c", null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

	
	
	public void loadXnxx()
	{

		String pathf = getFilesDir().toString()+"/sock64";
		try
		{	
			OutputStream myOutput = new FileOutputStream(pathf);
			byte[] buffer = new byte[1024];
			int length;
			InputStream myInput = getAssets().open("sock64");
			while ((length = myInput.read(buffer)) > 0) {
				myOutput.write(buffer, 0, length);
			}
			myInput.close();
			myOutput.flush();
			myOutput.close();

		}

		catch (IOException e)
		{ 
		}


		daemonPath64 = getFilesDir().toString()+"/sock64";


		try{
			Runtime.getRuntime().exec("chmod 777 "+daemonPath64);
		}
		catch (IOException e)
		{ 
		}

	}
	
	
	
	
    public void loadAssets() {
        String filesDir = getFilesDir().toString() + "/sock";
        try {
            OutputStream myOutput = new FileOutputStream(filesDir);
            byte[] buffer = new byte[1024];
            int length;
            InputStream myInput = getAssets().open("sock");
            while ((length = myInput.read(buffer)) > 0) {
                myOutput.write(buffer, 0, length);
            }
            myInput.close();
            myOutput.flush();
            myOutput.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        daemonPath = getFilesDir().toString() + "/sock";
        try {
            Runtime.getRuntime().exec("chmod 777 " + daemonPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadAssets64() {
        String filesDir = getFilesDir().toString() + "/sock64";
        try {
            OutputStream myOutput = new FileOutputStream(filesDir);
            byte[] buffer = new byte[1024];
            int length;
            InputStream myInput = getAssets().open("sock64");
            while ((length = myInput.read(buffer)) > 0) {
                myOutput.write(buffer, 0, length);
            }
            myInput.close();
            myOutput.flush();
            myOutput.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        daemonPath64 = getFilesDir().toString() + "/sock64";
        try {
            Runtime.getRuntime().exec("chmod 777 " + daemonPath64);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
