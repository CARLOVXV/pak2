package com.kazumodz.subakti;

import android.app.Activity;
import android.os.Bundle;
import com.kazumodz.subakti.R;
import android.os.Handler;
import android.content.Intent;
import android.content.Context;

public class LoadGalau extends Activity { 

    

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.loadgalau);
		int TIME_SPLASH = 9000;
		new Handler().postDelayed(new Runnable() {
				@Override
				public void run() { 
					startActivity(new Intent(getApplicationContext(), data.class));
					finish();
				}
			}, TIME_SPLASH);
	}

}

